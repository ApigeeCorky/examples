#!/bin/bash

# Ensure RHEL is registered with RHN.
is_registered=0
if [[ -f /etc/sysconfig/rhn/systemid ]] ; then
  is_registered=1
elif [[ -f /etc/yum.repos.d/redhat.repo ]] ; then
  sslclientcert=`grep sslclientcert /etc/yum.repos.d/redhat.repo | head -n 1 | cut -d "=" -f2 | tr -d " "`
  if [[ ! -z $sslclientcert && -f $sslclientcert ]] ; then
    is_registered=1
  fi
fi

if [[ $is_registered -eq 0 ]] ; then
  display_multiline "
--------------------------------------------------------------------------------
WARNING: Your system is not registered with Red Hat.

You must register your system with Red Hat in order to use official Red Hat RPM
repositories.  If you do not register your system, some needed RPM packages may
not be available which will cause this installer to fail.
"
  prompt_question_yes_or_no_default_yes "Do you want to register with Red Hat?" register_rhn

  if [[ $register_rhn = 'n' ]] ; then
    # Exit from this script.
    return 0
  fi
  rhn_user=
  rhn_pass=
  while [[ -z $rhn_user ]] ; do
    prompt_question_text_input "RHN username" rhn_user
  done
  while [[ -z $rhn_pass ]] ; do
    prompt_question_password_input "RHN password" rhn_pass
  done
  trap - ERR
  subscription-manager register --username="${rhn_user}" --password="${rhn_pass}" --auto-attach >> $logfile 2>&1
  rhn_registered=$?
  register_exception_handlers
  if [[ $rhn_registered -ne 0 ]] ; then
    display_error "Invalid credentials"
    display_error "The Red Hat Network credentials you entered were not correct, or there are licensing issues with your account."
    exit 1
  fi
  display "Registration succeeded."
fi

