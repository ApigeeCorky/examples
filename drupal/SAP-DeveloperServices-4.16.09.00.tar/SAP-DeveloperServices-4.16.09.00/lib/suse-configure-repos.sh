#!/bin/bash

# Expected vars:
#   $repo_subdir

dl_root=http://download.opensuse.org

display "Validating network is available"
until  curl -X HEAD ${dl_root}/repositories/ --silent --location --fail --head --max-time 5 >/dev/null 2>&1
do
  display_error "Could not reach ${dl_root}/repositories/."
  display_error "Please make sure this server is properly connected to the internet."
  prompt_question_text_input "Press <ENTER> to try again" ignore
done

repos=`zypper repos | tail -n +3 | cut -d "|" -f3`

if [[ $opdk_os_major -lt 12 ]] ; then
  # Sigh. Paths to repositories are now hardcoded.
  # This sad state of affairs is made necessary by the fact that some
  # repositories support SP3, others support SP4, and the main PHP repo only
  # supports SP2.
  if [[ $(echo "${repos}" | grep -c server_php) -eq 0 ]]; then
    display "Adding needed repo for full PHP support"
    zypper --gpg-auto-import-keys addrepo --no-gpgcheck ${dl_root}/repositories/server:/php/SLE_11_SP2 server_php >> $logfile 2>&1
    # Lower priority of repo so standard repos take precedent
    zypper mr -p 70 server_php >> $logfile 2>&1
  fi
  if [[ $(echo "${repos}" | grep -c devel_tools_scm) -eq 0 ]]; then
    # Needed for git
    display "Adding needed repo for git"
    zypper --gpg-auto-import-keys addrepo --no-gpgcheck ${dl_root}/repositories/devel:/tools:/scm/SLE_11_SP4 devel_tools_scm >> $logfile 2>&1
    # Lower priority of repo so standard repos take precedent
    zypper mr -p 70 devel_tools_scm >> $logfile 2>&1
  fi
  if [[ $(echo "${repos}" | grep -c devel_languages_perl) -eq 0 ]]; then
    # Needed for git. Note that this repo has a SP4 subdirectory, but it is not
    # valid. Use SP3 instead.
    display "Adding needed repo for git dependencies"
    zypper --gpg-auto-import-keys addrepo --no-gpgcheck ${dl_root}/repositories/devel:/languages:/perl/SLE_11_SP3 devel_languages_perl >> $logfile 2>&1
    # Lower priority of repo so standard repos take precedent
    zypper mr -p 70 devel_languages_perl >> $logfile 2>&1
  fi
elif [[ $opdk_os_major -eq 12 ]]; then
  if [[ $(echo "${repos}" | grep -c php7) -eq 0 ]]; then
    display "Adding needed repo for PHP 7 support"
    zypper --gpg-auto-import-keys addrepo --no-gpgcheck ${dl_root}/repositories/devel:/languages:/php:/php7/SLE_12_SP1 php7 >> $logfile 2>&1
    # Lower priority of repo so standard repos take precedent
    zypper mr -p 70 php7 >> $logfile 2>&1
  fi
fi

echo "Zypper repositories are properly configured."

