#!/bin/bash

# Register EPEL and IUS repos
# Expected vars:
#   $opdk_distro
#   $opdk_os_major

rpm -q epel-release > /dev/null 2>&1 && has_epel=1 || has_epel=0
if [[ $has_epel -eq 0 ]] ; then 
  display "Configuring EPEL repository... please be patient"
  rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-${opdk_os_major}.noarch.rpm >> $logfile 2>&1
  yum clean all  >> $logfile 2>&1
else
  display "EPEL repository is already installed and configured."
fi

rpm -q ius-release > /dev/null 2>&1 && has_ius=1 || has_ius=0
if [[ $has_ius -eq 0 ]]; then
  if [[ $opdk_distro == 'Redhat' || $opdk_distro == 'Oracle' ]]; then
    iusprefix="rhel${opdk_os_major}"
  else
    iusprefix="centos${opdk_os_major}"
  fi
  display "Configuring IUS repository... please be patient"
  rpm -Uvh https://${iusprefix}.iuscommunity.org/ius-release.rpm >> $logfile 2>&1
  yum clean all  >> $logfile 2>&1
else
  display "IUS repository is already installed and configured."
fi
