#!/bin/bash

# Detect existing packages which conflict with ones we are installing.
# At this time these all relate to PHP.
# Expected vars:
#   $platform_variant
#   $opdk_os_major

obsolete_packages=
case $platform_variant in
  rhel)
    # All php-related RPMs for Cent/RHEL should have php70u in their name to be valid.
    obsolete_packages=$( rpm -qa | grep php | grep -v 70u | sed -r -s 's/-[0-9].*$//g' | sort )
    remove_command="yum remove"
    ;;
  suse)
    if [[ $opdk_os_major == 11 ]]; then
      # Vanilla version of PHP is 5.3, we need to install 5.6
      obsolete_packages=$( rpm -qa | grep php53 | sed -r -s 's/-[0-9].*$//g' | sort )
    else
      # Vanilla version of PHP is 5.4, we need to install 7.0
      obsolete_packages=$( rpm -qa | grep php5 | sed -r -s 's/-[0-9].*$//g' | sort )
    fi
    remove_command="zypper remove"
    ;;
esac

if [[ ! -z $obsolete_packages ]]; then
  display_error "The following packages present on your system conflict with software we are"
  display_error "about to install. You will need to manually remove each one, then re-run"
  display_error "this install script."
  display_multiline "${obsolete_packages}"
  display "You can remove each of these with the following command:"
  display "  ${remove_command} <package-name>"
  exit 1
fi
