#!/bin/bash

# Expected vars:
#   $logfile
#   $has_network
#   $platform_variant
#   $opdk_os_major

case $platform_variant in
  rhel)
    if [[ $has_network -eq 1 ]]; then
      yum_options=
      php_pkg=php70u
    else
      yum_options="--disablerepo=* --enablerepo=devportal --nogpgcheck"
      php_pkg=mod_php70u
    fi
    apache_pkg=httpd
    php_modules="php70u-cli php70u-pdo php70u-mysqlnd php70u-gd php70u-xml \
      php70u-mbstring php70u-process php70u-json"
    install_command="yum -y ${yum_options} install"
    ;;
  suse)
    # zypper options are placed before the command.
    zypper_options="--non-interactive"
    # zypper install options are for the install command itself.
    # We need to use --force so the install does not send a non-zero status back.
    zypper_install_options="--auto-agree-with-licenses --force"
    if [[ $has_network -eq 0 ]]; then
      # Do not refresh, it will fail if no network.
      zypper_options="${zypper_options} --no-refresh"
      zypper_install_options="${zypper_install_options} --repo devportal"
    fi
    apache_pkg=apache2
    if [[ $opdk_os_major -lt 12 ]]; then
      php_pkg=php5
      # installing the above also installs the following:
      #   php5-ctype php5-dom php5-iconv php5-json php5-pdo php5-sqlite
      #   php5-tokenizer php5-xmlreader php5-xmlwriter
      php_modules="apache2-mod_php5 php5-curl php5-fileinfo php5-gd php5-gettext \
        php5-mbstring php5-mysql php5-openssl php5-pcntl php5-phar php5-posix \
        php5-readline php5-sockets php5-zip php5-zlib"
    else
      php_pkg=php7
      php_modules="apache2-mod_php7 php7-ctype php7-curl php7-dom php7-fileinfo \
        php7-gd php7-gettext php7-iconv php7-json php7-mbstring php7-mysql \
        php7-openssl php7-pcntl php7-pdo php7-phar php7-posix php7-readline \
        php7-sockets php7-sqlite php7-tokenizer php7-zip php7-zlib php5-pcntl"
    fi
    install_command="zypper ${zypper_options} install ${zypper_install_options}"
    ;;
esac

display "Installing Apache web server... please stand by"
display "-------------------------------------------------"
display "Command: $install_command $apache_pkg"
$install_command $apache_pkg >> $logfile 2>&1
display " "

display "Installing PHP... please stand by"
display "-------------------------------------------------"
display "Command: $install_command $php_pkg"
$install_command $php_pkg >> $logfile 2>&1
display " "

display "Installing PHP modules... please stand by"
display "-------------------------------------------------"
for php_module in $php_modules ; do
  display "Command: $install_command $php_module"
  $install_command $php_module >> $logfile 2>&1
done

display " "

