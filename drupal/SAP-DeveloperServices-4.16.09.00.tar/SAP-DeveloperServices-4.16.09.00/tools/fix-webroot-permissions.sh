#!/bin/sh

# TODO: unify this with the version under /resources

if [[ $( whoami ) != 'root' ]] ; then
  echo "$0 must be run as root (or run via sudo)."
  exit 1
fi

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do # resolve $SOURCE until the file is no longer a symlink
    DIR="$( cd -P "$( dirname "$source" )" && pwd )"
    source="$(readlink "$source")"
    [[ $source != /* ]] && source="$DIR/$source" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

logfile=permissions.log

# Load function library
source ${script_path}/../lib/bash_toolkit.sh

# Get OS and version information.
source ${script_path}/../lib/detect-os.sh

source ${script_path}/../lib/configure-apache-webroot-permissions.sh