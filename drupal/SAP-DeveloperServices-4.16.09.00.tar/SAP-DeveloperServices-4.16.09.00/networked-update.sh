#!/bin/bash

###############################################################################
# networked-update.sh - This script is used to update Dev Portal when the
# server is networked.
###############################################################################

# Are we running networked or non-networked.
has_network=1

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

# Path and filename of the Dev Portal custom tarball
devportal_profile_tarfile_path=${script_path}/resources/devportal_profile.tgz

# Load function library
source ${script_path}/lib/bash_toolkit.sh

# Create log file, setup traps for errors, etc.
script_initialize temp_dir

# Get OS and version information.
source ${script_path}/lib/detect-os.sh

# -----------------------------------------------------
# BEGINNING UPDATE PROCESS
# -----------------------------------------------------
display_h1 "Starting OPDK update.sh script ${script_rundate}"
os_info="$( cat $release_file | head -n 1 )"
display "${os_info}"

display_multiline "
--------------------------------------------------------------------------------
This script will upgrade the Apigee Developer Services Portal on this server.

IMPORTANT: Make sure you have backed up the Dev Portal database before
continuing. A backup of all files in the webroot will be created.

ALSO: This script presumes that Dev Portal owns all code not found in the /sites
directory. If you have made modifications outside of this directory, your
changes will be overwritten and/or deleted, with the exception of /robots.txt
(if it exists).

For more information, please see the OPDK-Dev-Portal-Install-Config-Guide.pdf
which you can get from Apigee Support or from the ftp.apigee.com server.
--------------------------------------------------------------------------------
"
display "This script will upgrade the Apigee Developer Services Portal on this server."
prompt_question_text_input "Press <ENTER> to continue" ignore

# Expected variables:
#   $logfile

display "Ensuring composer is installed and configured..."
source ${script_path}/lib/configure-composer.sh

# Ensure drush is installed
display "Ensuring Drush is installed..."
source ${script_path}/lib/install-drush.sh
# Get the webroot of apache
prompt_question_text_input "Where is the root directory of the devportal?" devportal_install_dir "/var/www/html"

# Install drupal into a temp directory
webroot="${temp_dir}/temp-webroot"
mkdir -pv $webroot >> $logfile 2>&1
source ${script_path}/lib/install-drupal.sh

# Blow away sites dir of our newly-created Drupal install.
rm -rf ${webroot}/sites
mkdir ${webroot}/sites
# Copy sites dir from live site into staging area, preserving all attributes.
cd ${devportal_install_dir}
tar cf - sites/* | ( cd ${webroot}; tar xpf - )
# Preserve robots.txt if it exists
if [[ -f robots.txt ]]; then
  cp robots.txt ${webroot}/
fi
is_installer_running=1
source ${script_path}/lib/configure-apache-webroot-permissions.sh

display "Pivoting updated webroot into place..."
backup_dir=${temp_dir}/html
# Move existing site dir to a backup location
mv $devportal_install_dir $backup_dir
# Move our staging area into live location
mv $webroot $devportal_install_dir

cd ${devportal_install_dir}
display "Running cleanup tasks..."
${drush_exe} sql-query "TRUNCATE TABLE cache_bootstrap" >> $logfile 2>&1
# Clean up old views handlers from the registry.
${drush_exe} sql-query "DELETE FROM registry WHERE name LIKE 'dda_handler%' OR name LIKE 'du_handler%'" >> $logfile 2>&1
${drush_exe} sql-query "DELETE FROM registry_file WHERE filename LIKE '%dda_handler%' OR filename LIKE '%du_handler%'" >> $logfile 2>&1
# If apigee_checklist was enabled, disable it, so we don't get spurious
# drush warnings on cron.
${drush_exe} sql-query "UPDATE system SET status = 0 WHERE name = 'apigee_checklist'" >> $logfile 2>&1
${drush_exe} rr >> $logfile 2>&1
display "Running database updates..."
${drush_exe} updb -y >> $logfile 2>&1
display "Enabling Update module if it was not already enabled..."
${drush_exe} en -y update >> $logfile 2>&1

display "Clearing caches and running cron..."
${drush_exe} cc all
${drush_exe} cron

display "Creating a backup tarball..."
cd $backup_dir
backup_file=/tmp/devportal-backup-$( date +%Y%m%d%H%M%S ).tar.gz
tar -czf $backup_file .htaccess .git* * >> $logfile 2>&1

cd ${script_path}
display "Final cleanup..."
rm -rf $backup_dir >> $logfile 2>&1

# ------------------------------------------------------------------------------
# Finished message!
# ------------------------------------------------------------------------------

display_multiline "
--------------------------------------------------------------------------------
Dev Portal Update Complete
--------------------------------------------------------------------------------
You have upgraded your version of Dev Portal.

A tarball backup of all files can be found here:
  ${backup_file}

The actions of this installer are written to a log here:
  ${logfile}
If you need support during this installation, please include the logfile in your
communication.

--------------------------------------------------------------------------------
"

exit 0
