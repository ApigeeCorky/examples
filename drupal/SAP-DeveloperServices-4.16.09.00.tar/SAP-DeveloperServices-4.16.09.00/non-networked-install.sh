#!/bin/bash

###############################################################################
# non-networked-install.sh - This script is used to create a offline installer
# to allow installations on a server not connected to the Internet.  Run
# this script on a network-connected server of the same OS and version as your
# target.
###############################################################################

###############################################################################
# FUNCTIONS
###############################################################################

function install_dependency() {
  local package_exists=0
  local this_package=$1
  local extra_suse_repos=
  local this_repo=

  case $platform_variant in
    rhel)
      trap - ERR
      rpm -q > /dev/null 2>&1 $this_package && package_exists=1
      register_exception_handlers
      if [[ $package_exists -eq 0 ]] ; then
        yum install -y $this_package >> $logfile 2>&1
      fi
      ;;
    suse)
      if [[ $opdk_os_major -eq 12 ]] ; then
        extra_suse_repos=php7
      else
        extra_suse_repos="devel_languages_perl devel_tools_scm server_php server_php_extensions"
      fi

      trap - ERR
      rpm -q > /dev/null 2>&1 $this_package && package_exists=1
      register_exception_handlers
      if [[ $package_exists -eq 0 ]] ; then
        # Createrepo gets special handling. We have to disable all extra
        # repositories, or we will get Python conflicts.
        if [[ $this_package == 'createrepo' ]]; then
          # disable extra repos
          for this_repo in $extra_suse_repos; do
            zypper modifyrepo -d $this_repo >> $logfile 2>&1
          done
        fi
        zypper --non-interactive install $this_package >> $logfile 2>&1
        if [[ $this_package == 'createrepo' ]]; then
          # re-enable extra repos
          for this_repo in $extra_suse_repos; do
            zypper modifyrepo -e $this_repo >> $logfile 2>&1
          done
        fi
      fi
      ;;
  esac

}

###############################################################################
# MAIN
###############################################################################

if [[ $( whoami ) != 'root' ]] ; then
  echo "$0 must be run as root (or run via sudo)."
  exit 1
fi

has_network=1
cwd=$( pwd )
drush_home=/usr/local/share/drush
drush_version=7.3.0

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $source until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

# Load command line args script
source ${script_path}/lib/bash_cmd_args.sh

# Load function library
source ${script_path}/lib/bash_toolkit.sh

# Create log file, setup traps for errors, etc.
script_initialize

# Get OS and version information.
source ${script_path}/lib/detect-os.sh

# Create temp directory.  Use $temp_dir for any temporary files/dirs.
create_tmp_dir temp_dir >> $logfile 2>&1

# -----------------------------------------------------
# Starting Installation
# -----------------------------------------------------

display_h1 "Starting non networked bundle creation ${script_rundate}"
os_info=$( cat $release_file | head -n 1 )
display "${os_info}"

source ${script_path}/lib/configure-proxy.sh

# -----------------------------------------------------
# Validating Internet connectivity
# -----------------------------------------------------
source ${script_path}/lib/validate-network.sh

# -----------------------------------------------------
# Yum/Zypper repository configuration
# -----------------------------------------------------
display_h1 "Repository Configuration"
case $platform_variant in
  rhel)
    if [[ $opdk_distro == 'Redhat' ]]; then
      source ${script_path}/lib/register-rhn.sh
    fi
    source ${script_path}/lib/configure-ius.sh
    ;;
  suse)
    source ${script_path}/lib/suse-ensure-base-repo.sh
    source ${script_path}/lib/suse-configure-repos.sh
    ;;
esac

# -----------------------------------------------------
# Configure offline installer path and file
# -----------------------------------------------------

# The name of the tar file without the .tar.gz extension.
repo_tarball_filename=devportal-binary-bundle-${opdk_distro}-${opdk_os_major}-${opdk_platform}
# The actual tar name with extension.
# Note: this code is copied and used in test/test.sh to generate filename
repo_tarball=${repo_tarball_filename}.tar.gz
# Make a temp installer dir with
tar_temp_dir="${temp_dir}/${repo_tarball_filename}"

# Let user choose where to put bundle, but make sure dir is absolute and is valid.
is_valid_install_dir=0
while [ $is_valid_install_dir -eq 0 ]; do

  # Let user choose where to put dir, but make sure dir path is absolute.
  while [ $is_valid_install_dir -eq 0 ]; do
    prompt_question_text_input "Where should the installer tarball be created?" bundle_root $HOME
    regex="^/"
    if [[ $bundle_root =~ $regex ]]; then
      is_valid_install_dir=1
    else
      is_valid_install_dir=0
      display_error "Please enter an absolute directory path."
    fi
  done

  # Assume is_valid_install_dir until find out otherwise.
  is_valid_install_dir=1

  # Assume install dir is not a file unless we find out otherwise.
  is_install_dir_a_file=0

  # If file location is a file and not a dir
  if [ -f ${bundle_root}/${repo_tarball}  ]; then
    display_error "Installer tarball file exists: ${bundle_root}/${repo_tarball}"
    prompt_question_yes_or_no_default_yes "Would you like to delete this file? If you choose 'N', you will be asked to enter a different install directory." delete_install_file
    # Delete files
    if [[ $delete_install_file == "y" ]]; then
      rm -rf ${bundle_root}/${repo_tarball}   >> $logfile 2>&1
    else
      unset devportal_install_dir
      is_valid_install_dir=0
      is_install_dir_a_file=1
    fi
  fi

  # Create the dir if it DNE
  if [ -d $bundle_root ] ; then
    display "installer tarball directory already exists: ${bundle_root}"
  else
    # Only mkdir if install dir is not a file (will loop again).
    if [ ! -f $bundle_root ]; then
      mkdir --mode=755 -p $bundle_root >> $logfile 2>&1
    fi
  fi
done
display "Installer tarball will be installed in: ${bundle_root}."


# -----------------------------------------------------------
# Install tools needed for creating offline installer
# -----------------------------------------------------------
# Make sure we can create a repo
display_h1 "Installing some needed tools"
case $platform_variant in
  rhel)
    required_utils="createrepo unzip patch yum-utils php70u-cli git php70u-process php70u-xml php70u-json"
    ;;
  suse)
    if [[ $opdk_os_major -eq 12 ]]; then
      php_required="php7 php7-curl php7-dom php7-fileinfo php7-json php7-openssl php7-pcntl php7-phar php7-posix php7-readline"
    else
      php_required="php5 php5-curl php5-fileinfo php5-openssl php5-pcntl php5-phar php5-posix php5-readline"
    fi
    required_utils="createrepo unzip patch git-core ${php_required}"
    ;;
esac

for required_util in $required_utils ; do
  display_nonewline "."
  install_dependency $required_util
done
display_nonewline "."
mkdir -p ${tar_temp_dir}/devportal-repo >> $logfile 2>&1
display "done"

# Commence ethernet saturation
package_list_dir=${script_path}/resources
display_h1 "Downloading binary packages"
display_nonewline "."
pkg_install=
for pkg in $( cat ${package_list_dir}/packagelist-${opdk_distro}-${opdk_os_major}.txt ); do
  case $platform_variant in
    suse)
      # For SuSE, we download one at a time so we can move the RPM to the right place
      rpm=$(zypper --non-interactive install --force --download-only $pkg | tee -a $logfile  | grep "^Forcing installation of " | cut -d "'" -f2 ).rpm
      rpm_path=$( find /var/cache/zypp/packages -type f -name ${rpm} | head -n 1 )
      mv "${rpm_path}" "${tar_temp_dir}"/devportal-repo >> $logfile 2>&1
      ;;
    rhel)
      # for RHEL/CentOS and Ubuntu, we will invoke the downloader in one fell swoop
      pkg_install="${pkg_install} ${pkg}"
      yumdownloader --destdir ${tar_temp_dir}/devportal-repo ${pkg} >> $logfile 2>&1
      err=$?
      if [ $err -ne 0 ] ; then
        display_error "Could not retrieve package \"${pkg}\"."
        display "You will need to register a repository containing this RPM."
        exit
      fi
      ;;
  esac
done
display "done"

if [[ $platform_variant == 'rhel' && $opdk_os_major -eq 6 ]] ; then
  trap - ERR
  # Try to keep the repository clear of platform-unusable RPMs
  rm ${tar_temp_dir}/devportal-repo/*.i686.*.rpm 2>/dev/null
  register_exception_handlers
fi

display_h1 "Initializing Dev Portal repository"
createrepo ${tar_temp_dir}/devportal-repo/  >> $logfile 2>&1

# Also pick up the default install config file.
if [ -e "${config_file}" ]; then
  cp -R ${config_file} ${tar_temp_dir}
fi

# Install composer before trying to install Drush.
source $script_path/lib/configure-composer.sh

# If our drush install previously was found, remove it and install new one.
if [[ -f /usr/local/bin/drush || -L /usr/local/bin/drush ]] ; then
  rm -rf /usr/local/bin/drush >> $logfile 2>&1
fi
if [[ -d /usr/local/drush ]] ; then
  rm -rf /usr/local/drush >> $logfile 2>&1
fi
if [[ -d /usr/local/share/drush ]] ; then
  rm -rf /usr/local/share/drush >> $logfile 2>&1
fi

display_h1 "Bundling drush"

curl -LkSs -o ${temp_dir}/drush.tar.gz https://codeload.github.com/drush-ops/drush/tar.gz/${drush_version} >> $logfile 2>&1
err=$?
if [[ $err -ne 0 ]] ; then
  display_error "curl error code: $err while running the following command:"
  display_error "  curl -LkSs -o ${temp_dir}/drush.tar.gz https://codeload.github.com/drush-ops/drush/tar.gz/${drush_version}"
  display "Make sure your system is properly networked and run the installer again."
  exit
fi

tar -C $( dirname $drush_home ) -xzf ${temp_dir}/drush.tar.gz
mv $( dirname $drush_home )/drush-${drush_version} $drush_home
composer install --no-dev --no-progress --no-ansi --working-dir=$drush_home  >> $logfile 2>&1
err=$?
if [[ $err -ne 0 ]] ; then
  display_error "composer error code: $err while running the following command:"
  display_error "  composer install --no-dev --no-progress --no-ansi --working-dir=$drush_home"
  display "Make sure your system is properly networked and run the installer again."
  exit
fi
patch -d $drush_home -p1 < ${script_path}/resources/drush-7.3.0-dont-use-wget.patch  >> $logfile 2>&1
ln -s $drush_home/drush /usr/local/bin/drush
drush_exe=/usr/local/bin/drush

# Enable drush rr if it is not already present.
if [[ $( $drush_exe help | grep -c registry-rebuild ) -eq 0 ]]; then
  display "Installing registry-rebuild drush task..."
  $drush_exe dl registry_rebuild >> $logfile 2>&1
fi
# Put drush rr command files where they can be bundled with drush for
# non-networked installs.
if [[ -d $drush_home && -d ${HOME}/.drush/registry_rebuild && ! -d ${drush_home}/commands/registry_rebuild ]] ; then
  cp -R ${HOME}/.drush/registry_rebuild ${drush_home}/commands/ >> $logfile 2>&1
fi

cwd=`pwd`
cd $drush_home
tar cf ${tar_temp_dir}/drush.tar ./* >> $logfile 2>&1
cd $cwd

# Bundle Drupal tarball
webroot=${tar_temp_dir}/devportal-webroot
mkdir -p $webroot  >> $logfile 2>&1
source $script_path/lib/install-drupal.sh

display_h1 "Creating repository tarball"

if [[ $script_path != ${tar_temp_dir} ]] ; then
  cp -R $script_path/lib ${tar_temp_dir}  >> $logfile 2>&1
  mv ${tar_temp_dir}/lib/install-from-rpm-bundle.sh ${tar_temp_dir}  >> $logfile 2>&1
fi

cwd=$( pwd )
cd $temp_dir >> $logfile 2>&1
tar --exclude='.git' --exclude='.gitignore' --exclude="*.DS_Store" -czf ${bundle_root}/${repo_tarball} ${repo_tarball_filename}  >> $logfile 2>&1
cd $cwd  >> $logfile 2>&1

display "Repository tarball created at ${bundle_root}/$repo_tarball."

# ------------------------------------------------------------------------------
# Finished message!
# ------------------------------------------------------------------------------

display_multiline "
--------------------------------------------------------------------------------
Non-Networked Installer Created
--------------------------------------------------------------------------------
The installer tarball is created:

${bundle_root}/${repo_tarball}

You will now need to move this tarball to the non networked system and
run the following commands:

tar -xvf ${repo_tarball}
cd ${repo_tarball_filename}
chmod 755 install-from-rpm-bundle.sh
sudo ./install-from-rpm-bundle.sh

The actions of this installer are written to a log here: ${logfile}
If you need support during this installation, please include the logfile in your
communication.

--------------------------------------------------------------------------------
"

exit 0
