#!/bin/bash

if [[ $( whoami ) != 'root' ]] ; then
  echo "$0 must be run as root (or run via sudo)."
  exit 1
fi

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $source until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"
drupal_root="$( cd -P "$( dirname "$script_path" )" && pwd )"

prompt_question_text_input() {
  local question_message=$1
  local resultvar=$2
  local default_value=$3

  # Grab the value of the variable that is referred to as an argument
  # (yes, it's like that)
  eval response_var=\$$2
  # Then check to see if said variable has already been set
  if [ -z "$response_var" ]; then

    if [[ ! -z $default_value ]]; then
      echo -n "${question_message?} [${default_value}]: "
    else
      echo -n "${question_message?} : "
    fi
    read answer
    if [[ -z $answer && ! -z $default_value ]]; then
      eval $resultvar="'$default_value'"
    else
      eval $resultvar="'$answer'"
    fi
  else
    eval $resultvar=\$$2
  fi
}

# Webroot should by default owned by user running this script.
is_valid_user=0
script_user=$( whoami )
# Make sure user is valid on this system by checking against /etc/passwd
until [[ $is_valid_user -ne 0 ]] ; do
  prompt_question_text_input "What user should own the devportal files in the webroot? " devportal_owner $script_user
  is_valid_user=$( grep -c "^${devportal_owner}:" /etc/passwd )
  if [[ $is_valid_user -eq 0 ]]; then
    echo "${devportal_owner} is not a valid user on this system. Please try again."
  fi
done

if [[ -f /etc/redhat-release ]]; then
  # This is RHEL or CentOS.
  devportal_group=$(grep "^Group" /etc/httpd/conf/httpd.conf | head -n 1 | cut -d " " -f2)
elif [[ -f /etc/SuSE-release ]]; then
  # This is SUSE.
  devportal_group="www"
  if [[ -f /etc/apache2/uid.conf ]] ; then
    devportal_group=$( grep Group /etc/apache2/uid.conf | cut -d " " -f2 )
  fi
elif [[ -f /etc/os-release ]]; then
  # This is a Debian variant.
  devportal_group="www-data"
  if [[ -f /etc/apache2/envvars ]] ; then
    devportal_group=$( grep APACHE_RUN_GROUP /etc/apache2/envvars | cut -d "=" -f2 )
  fi
else
  is_valid_group=0
  script_group=
  # Make sure group is valid on this system by checking against /etc/group
  until [[ $is_valid_group -ne 0 ]]; do
    prompt_question_text_input "What group does the web server run as? " devportal_group $script_group
    is_valid_group=$( grep -c "^${devportal_group}:" /etc/group )
    if [[ $is_valid_user -eq 0 ]]; then
      echo "${devportal_group} is not a valid group on this system. Please try again."
    fi
  done
fi

echo "Setting permissions under webroot ${drupal_root}"
echo "  to owner ${devportal_owner}"
echo "  and group ${devportal_group}"

chown -R ${devportal_owner}:${devportal_group} $drupal_root

find ${drupal_root} -type d -exec chmod u=rwx,g=rx,o= '{}' \;
find ${drupal_root} -type f -exec chmod u=rw,g=r,o= '{}' \;
find ${drupal_root}/sites -type d -name files -exec chmod ug=rwx,o= '{}' \;
for x in ${drupal_root}/sites/*/files; do
  find ${x} -type d -exec chmod ug=rwx,o= '{}' \;
  find ${x} -type f -exec chmod ug=rw,o= '{}' \;
done
find ${drupal_root}/sites -type d -name private -exec chmod ug=rwx,o= '{}' \;
chmod 640 ${drupal_root}/sites/default/settings.php
chmod 770 ${drupal_root}/sites/default/tmp

echo "Done."

