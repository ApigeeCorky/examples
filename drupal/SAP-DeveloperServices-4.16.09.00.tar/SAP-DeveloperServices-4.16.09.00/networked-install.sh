#!/bin/bash

###############################################################################
# networked-install.sh - This script is used to install Dev Portal on a
# server with a network connection.
###############################################################################

if [[ $( whoami ) != 'root' ]] ; then
  echo "$0 must be run as root (or run via sudo)."
  exit 1
fi

# Are we running networked or non-networked.
has_network=1

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $source until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

# Load command line args script
source ${script_path}/lib/bash_cmd_args.sh

# Load function library
source ${script_path}/lib/bash_toolkit.sh

# Create log file, setup traps for errors, etc.
script_initialize

# Get OS and version information.
source ${script_path}/lib/detect-os.sh

# Create temp directory.  Use $temp_dir for any temporary files/dirs.
create_tmp_dir temp_dir >> $logfile 2>&1

# -----------------------------------------------------
# Starting Installation
# -----------------------------------------------------

display_h1 "Starting networked installation ${script_rundate}"
os_info="$( cat $release_file | head -n 1 )"
display "${os_info}"

display "This script will install a default Developer Portal on this server."
prompt_question_yes_or_no_default_yes "Do you wish to continue?" ignore

source ${script_path}/lib/configure-proxy.sh

source ${script_path}/lib/find-obsolete-packages.sh

# -----------------------------------------------------
# Validating Internet connectivity
# -----------------------------------------------------
source ${script_path}/lib/validate-network.sh

# -----------------------------------------------------
# STEP 1: Yum/Zypper repository configuration
# -----------------------------------------------------

display_h1 "Step 1 of 6: Repository Configuration"
case $platform_variant in
  rhel)
    if [[ $opdk_distro == 'Redhat' ]]; then
      source ${script_path}/lib/register-rhn.sh
    fi
    source ${script_path}/lib/configure-ius.sh
    ;;
  suse)
    source ${script_path}/lib/suse-ensure-base-repo.sh
    source ${script_path}/lib/suse-configure-repos.sh
    ;;
esac

# -----------------------------------------------------
# STEP 2: Install Apache and PHP software packages
# -----------------------------------------------------
display_h1 "Step 2 of 6: Install Apache and PHP Software Packages"

source ${script_path}/lib/install-required-pkgs.sh
source ${script_path}/lib/configure-php.sh


# -----------------------------------------------------
# STEP 3: Install and Configure Database
# -----------------------------------------------------
display_h1 "Step 3 of 6: Install and Configure Database"
source ${script_path}/lib/install-mysqld.sh


# -----------------------------------------------------
# STEP 4: Configure Apache Web Server
# -----------------------------------------------------
display_h1 "Step 4 of 6: Configure Apache Web Server"
source ${script_path}/lib/configure-apache.sh

# ------------------------------------------------------------------------------
# STEP 5: Dev Portal installation
# ------------------------------------------------------------------------------
display_h1 "Step 5 of 6: Dev Portal installation"

# Validate PHP
display "Validating PHP installation..."
trap - ERR
php_path="$( which php 2>/dev/null )"
register_exception_handlers
if [[ -z $php_path ]] ; then
  display_error "PHP executable not found."
  exit 1
fi

display "Validating command line tools..."
[[ $platform_variant == 'suse' ]] && git_pkg=git-core || git_pkg=git
# TODO: When bootstrap_modal_forms can be downloaded directly instead of cloned from a sandbox, we should remove git from the list of dependencies here.
for dependency in unzip patch $git_pkg ; do
  rpm -q $dependency >/dev/null 2>&1 && has_dependency=1 || has_dependency=0
  if [[ $has_dependency -eq 0 ]] ; then
    display "Package: ${dependency} not found, installing..."
    case $platform_variant in
      rhel)
        yum install -y $dependency >> $logfile 2>&1
        ;;
      suse)
        zypper --non-interactive install --auto-agree-with-licenses $dependency >> $logfile 2>&1
        ;;
    esac
    display "$dependency installed."
  fi
done

# To accommodate drush 7, composer must be installed before drush.
display "Installing composer..."
source ${script_path}/lib/configure-composer.sh

display "Installing Drush..."
source ${script_path}/lib/install-drush.sh

# Set the webroot to the install directory the user selected during Apache install.
display "Installing Drupal..."
webroot=${devportal_install_dir}
source ${script_path}/lib/install-drupal.sh

display "Setting Dev Portal permissions..."
webroot=${devportal_install_dir}
is_installer_running=1
source ${script_path}/lib/configure-apache-webroot-permissions.sh

# ------------------------------------------------------------------------------
# STEP 6: Modifying SELinux and Firewall to allow incoming HTTP connections.
# ------------------------------------------------------------------------------
display_h1 "Step 6 of 6: Modifying security settings to allow incoming HTTP connections."
source ${script_path}/lib/configure-security.sh

# ------------------------------------------------------------------------------
# Finished message!
# ------------------------------------------------------------------------------

display_multiline "
--------------------------------------------------------------------------------
Dev Portal Installation Complete
-------------------------------------------------------------------------------
You are ready to configure your Dev Portal by going to the following URL using
your local web browser:

http://${portal_hostname}

Keep the following information for the rest of the install and for future
reference.

Apache Configuration
--------------------
Dev Portal URL: http://${portal_hostname}
Dev Portal web root: ${devportal_install_dir}

Database Configuration
----------------------
Dev Portal database hostname: ${db_host}
Dev Portal database port: ${db_port}
Dev Portal database name: ${db_name}
Dev Portal database user: ${db_user}
Dev Portal database password: ******* (not shown)

--------------------------------------------------------------------------------
"

exit 0

