#!/bin/bash

###############################################################################
# install-update.sh - This script is used to update Dev Portal from a generated
# tarball when the server is not networked.
###############################################################################

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

temp_dir=/tmp
logfile=${temp_dir}/install-$( date +%Y%m%d%H%M%S ).log

# Path and filename of the Dev Portal custom tarball
devportal_tarfile_path=${script_path}/devportal.tar

# -----------------------------------------------------
# BEGINNING UPDATE PROCESS
# -----------------------------------------------------
echo "Starting OPDK install-update.sh script ${script_rundate}"

echo
echo "--------------------------------------------------------------------------------"
echo "This script will upgrade the Apigee Developer Services Portal on this server."
echo
echo "IMPORTANT: Make sure you have backed up the Dev Portal database before"
echo "continuing. A backup of all files in the webroot will be created."
echo
echo "ALSO: This script presumes that Dev Portal owns all code not found in the /sites"
echo "directory. If you have made modifications outside of this directory, your"
echo "changes will be overwritten and/or deleted, with the exception that /robots.txt"
echo "will be preserved if present."
echo
echo "For more information, please see the OPDK-Dev-Portal-Install-Config-Guide.pdf"
echo "which you can get from Apigee Support or from the ftp.apigee.com server."
echo "--------------------------------------------------------------------------------"
echo
echo "This script will upgrade the Apigee Developer Services Portal on this server."
echo "press <ENTER> to continue."
read ignore

php_exe=$( which php 2>/dev/null )
if [[ -z $php_exe ]]; then
  echo "PHP executable not found."
  exit 1
fi

echo -n "Where is the root directory of the devportal? [/var/www/html] "
read real_webroot
if [[ -z $real_webroot ]]; then
  real_webroot=/var/www/html
fi
if [[ ! -d $real_webroot ]]; then
  echo "The directory ${real_webroot} does not exist."
  exit 1
fi
if [[ ! -d ${real_webroot}/sites ]]; then
  echo "The directory ${real_webroot} does not appear to contain a Drupal install."
  exit 1
fi

# Determine if we should (re)install drush.
# We do so every time if we're sure we can do so safely.
drush_exe=$( which drush 2>/dev/null )
install_drush=0
if [[ ! -z $drush_exe ]]; then
  if [[ -d /usr/local/share/drush ]]; then
    # Blow away existing drush install so we can install known-good copy.
    rm -rf /usr/local/share/drush
    install_drush=1
  fi
else
  install_drush=1
fi
# If we can safely install drush, do so now.
if [[ $install_drush -eq 1 ]]; then
  tar -C /usr/local/share -xf ${script_path}/drush.tar >> $logfile 2>&1
fi

# Install drupal into a temp directory
webroot="${temp_dir}/temp-webroot"
mkdir -pv $webroot >> $logfile 2>&1
tar -C $webroot -xf ${script_path}/devportal.tar

# Blow away sites dir of our newly-created Drupal install.
rm -rf ${webroot}/sites
mkdir ${webroot}/sites
# Copy sites dir from live site into staging area, preserving all attributes.
cd $real_webroot
tar cf - sites/* | ( cd ${webroot}; tar xpf - )
# Preserve robots.txt if it exists
if [[ -f robots.txt ]]; then
  cp robots.txt ${webroot}/
fi
cd $script_path
# Set ownership of Drupal files.
# Do not source this file; it must be run in its own process.
${webroot}/scripts/fix-webroot-permissions.sh

echo "Pivoting updated webroot into place..."
backup_dir=${temp_dir}/html
# Move existing site dir to a backup location
mv $real_webroot $backup_dir
# Move our staging area into live location
mv $webroot $real_webroot

cd ${real_webroot}
echo "Running cleanup tasks..."
${drush_exe} sql-query "TRUNCATE TABLE cache_bootstrap" >> $logfile 2>&1
# Clean up old views handlers from the registry.
${drush_exe} sql-query "DELETE FROM registry WHERE name LIKE 'dda_handler%' OR name LIKE 'du_handler%'" >> $logfile 2>&1
${drush_exe} sql-query "DELETE FROM registry_file WHERE filename LIKE '%dda_handler%' OR filename LIKE '%du_handler%'" >> $logfile 2>&1
# If apigee_checklist was enabled, disable it, so we don't get spurious
# drush warnings on cron.
${drush_exe} sql-query "UPDATE system SET status = 0 WHERE name = 'apigee_checklist'" >> $logfile 2>&1
${drush_exe} rr --fire-bazooka >> $logfile 2>&1
echo "Running database updates..."
${drush_exe} updb -y >> $logfile 2>&1
echo "Enabling Update module if it was not already enabled..."
${drush_exe} en -y update >> $logfile 2>&1

echo "Clearing caches and running cron..."
${drush_exe} cc all
${drush_exe} cron

echo "Creating a backup tarball..."
backup_file=${temp_dir}/devportal-backup-$( date +%Y%m%d%H%M%S ).tar.gz
tar -C $backup_dir -czf $backup_file .htaccess .git* * >> $logfile 2>&1

cd ${script_path}
echo "Final cleanup..."
rm -rf $backup_dir >> $logfile 2>&1

# ------------------------------------------------------------------------------
# Finished message!
# ------------------------------------------------------------------------------

echo
echo "--------------------------------------------------------------------------------"
echo "Dev Portal Update Complete"
echo "--------------------------------------------------------------------------------"
echo "You have upgraded your version of Dev Portal."
echo
echo "A tarball backup of all files can be found here:"
echo "  ${backup_file}"
echo
echo "The actions of this installer are written to a log here:"
echo "  ${logfile}"
echo "If you need support during this installation, please include the logfile in your"
echo "communication."
echo "--------------------------------------------------------------------------------"
echo

exit 0
