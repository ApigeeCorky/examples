#!/bin/bash

###############################################################################
# non-networked-update.sh - This script is used to create a offline updater
# to update Dev Portal running on a server not connected to the Internet. You
# can run this script on any network-connected Unix-ish box (Linux, BSD, OSX).
#
# You should be aware that if drush is present on this box, it will be deleted
# and then reinstalled, so we can be sure we are bundling a version patched to
# run on PHP 5.3.3.
###############################################################################

has_network=1
drush_home=/usr/local/share/drush
drush_version=7.1.0

# Where can we temporarily write?
# TODO: /var/tmp often has more space than /tmp.
temp_dir=/tmp

# Configure scratch space for creating tarball
tarball_root=${temp_dir}/devportal-update
[[ -d $tarball_root || -f $tarball_root || -L $tarball_root ]] && rm -rf $tarball_root
mkdir -p $tarball_root

# Get directory this script is running in and put it in SCRIPT_PATH
source="${BASH_SOURCE[0]}"
while [ -h "$source" ]; do
  # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$source" )" && pwd )"
  source="$(readlink "$source")"
  # if $SOURCE was a relative symlink, we need to resolve it relative to the
  # path where the symlink file was located
  [[ $source != /* ]] && source="$DIR/$source"
done
script_path="$( cd -P "$( dirname "$source" )" && pwd )"

# Load function library
source ${script_path}/lib/bash_toolkit.sh
source ${script_path}/lib/bash_input.sh

# Create log file, setup traps for errors, etc.
script_initialize temp_dir

source ${script_path}/lib/configure-proxy.sh

# TO TEST:
# On a base CentOS 6.x box, installed the following:
#   php-cli php-process php-xml unzip patch git

display_multiline "
--------------------------------------------------------------------------------
This script will prepare a tarball of Drupal files to be installed in the
webroot of a working Dev Portal instance.

IMPORTANT: Make sure you have backed up the Dev Portal database and files before
continuing.

This script presupposes the following:

1. PHP of at least version 5.3.3 is installed on this machine.
2. Your network is configured and can reach the internet via http and https.
3. If composer is not installed, you have write access to /usr/local/bin to
   install it.
4. If drush is not installed, you have write access to /usr/local/share/drush
   and /usr/local/bin to install it. Additionally you will need the following
   PHP extensions: pcntl, posix, readline, xml
   You can see which extensions are installed via the following command:
         php -m
5. The following command-line utilities are installed: git, patch, unzip
6. You have write access to ${temp_dir}.
--------------------------------------------------------------------------------
"

display "Press <ENTER> to continue or <CTRL-C> to exit."
read ignore

# Ensure reasonably recent PHP
trap - ERR
php_exe=$( which php 2>/dev/null )
if [[ -z $php_exe ]] ; then
  display_error "PHP executable was not found."
  exit 1
fi
php_recent_enough=$( $php_exe -r "echo version_compare(PHP_VERSION, '5.3.3', '>=');" )
if [[ "${php_recent_enough}" != "1" ]]; then
  display_error "The installed PHP version is too old."
  exit 1
fi
# If we need to install drush, make sure required PHP exts are present.
drush_exe=$( which drush 2>/dev/null )
# Drush 8 may conceivably have been installed as a phar.
if [[ -z $drush_exe ]]; then
  drush_exe=$( which drush.phar 2>/dev/null )
fi
if [[ -z $drush_exe ]]; then
  php_extensions="$( $php_exe -m )"
  missing_extensions=
  for extension in pcntl posix readline; do
    if [[ $( echo $php_extensions | grep -c $extension ) -eq 0 ]]; then
      missing_extensions="${missing_extensions} ${extension}"
    fi
  done
  if [[ "${missing_extensions}" != "" ]]; then
    display_error "Your PHP install is missing the following extension(s):"
    display_error "  ${missing_extensions}"
    display_error "Please install them and then re-run this script."
    exit 1
  fi
fi
for exe in unzip patch git; do
  if [[ "$( which $exe 2>/dev/null )" == "" ]]; then
    display_error "$exe executable was not found."
    exit 1
  fi
done
register_exception_handlers

# Ensure network access.
source ${script_path}/lib/validate-network.sh

# Ensure composer installed.
# If drush 7 is going to be installed, composer needs to be installed first.
source ${script_path}/lib/configure-composer.sh

# Ensure drush is present.
# If a drush install previously was found, remove it and install new one.
if [[ -f /usr/local/bin/drush || -L /usr/local/bin/drush ]] ; then
  rm -rf /usr/local/bin/drush >> $logfile 2>&1
fi
if [[ -d /usr/local/drush ]] ; then
  rm -rf /usr/local/drush >> $logfile 2>&1
fi
if [[ -d /usr/local/share/drush ]] ; then
  rm -rf /usr/local/share/drush >> $logfile 2>&1
fi
display_h1 "Bundling drush"

curl -LkSs -o ${temp_dir}/drush.tar.gz https://codeload.github.com/drush-ops/drush/tar.gz/${drush_version} >> $logfile 2>&1
err=$?
if [[ $err -ne 0 ]] ; then
  display_error "curl error code: $err while running the following command:"
  display_error "  curl -LkSs -o ${temp_dir}/drush.tar.gz https://codeload.github.com/drush-ops/drush/tar.gz/${drush_version}"
  display "Make sure your system is properly networked and run the installer again."
  exit
fi

tar -C $( dirname $drush_home ) -xzf ${temp_dir}/drush.tar.gz
mv $( dirname $drush_home )/drush-${drush_version} $drush_home
cd $drush_home
# Unconditionally patch drush 7. The patch won't hurt anything on PHP > 5.3.3.
patch -p1 < ${script_path}/resources/drush-php533.patch
composer install --no-dev --no-progress --no-ansi --working-dir=$drush_home  >> $logfile 2>&1
err=$?
if [[ $err -ne 0 ]] ; then
  display_error "composer error code: $err while running the following command:"
  display_error "  composer install --no-dev --no-progress --no-ansi --working-dir=$drush_home"
  display "Make sure your system is properly networked and run the installer again."
  exit
fi
ln -s $drush_home/drush /usr/local/bin/drush
drush_exe=/usr/local/bin/drush
# Enable drush rr if it is not already present.
if [[ $( $drush_exe help | grep -c registry-rebuild ) -eq 0 ]]; then
  display "Installing registry-rebuild drush task..."
  $drush_exe dl registry_rebuild >> $logfile 2>&1
fi
# Put drush rr command files where they can be bundled with drush for
# non-networked installs.
if [[ -d $drush_home && -d ${HOME}/.drush/registry_rebuild && ! -d ${drush_home}/commands/registry_rebuild ]] ; then
  cp -R ${HOME}/.drush/registry_rebuild ${drush_home}/commands/ >> $logfile 2>&1
fi
tar -C $( dirname $drush_home ) -cf ${tarball_root}/drush.tar drush
display "Drush tarball created."

# Make sure temporary webroot exists and is empty.
webroot=${temp_dir}/devportal-webroot
if [[ -d $webroot ]] ; then
  rm -rf $webroot
fi
mkdir -p $webroot

# Make a full Drupal install.
source ${script_path}/lib/install-drupal.sh

# Remove contents of sites/default; we don't want to stomp on existing db settings.
rm -rf ${webroot}/sites/default/{settings.php,files,private,tmp}
# Add set-permissions script to tarball
mkdir -p ${webroot}/scripts
cp ${script_path}/resources/fix-webroot-permissions.sh ${webroot}/scripts/
chmod +x ${webroot}/scripts/fix-webroot-permissions.sh

display "Bundling Drupal."
cd $webroot
tar -cf ${tarball_root}/devportal.tar .htaccess * >> $logfile 2>&1
cd $script_path

cp ${script_path}/resources/install-update.sh $tarball_root/
chmod +x ${tarball_root}/install-update.sh

# Let user choose where to put tarball, but make sure dir is absolute and is valid.
is_valid_install_dir=0
while [ $is_valid_install_dir -eq 0 ]; do

  while [ $is_valid_install_dir -eq 0 ]; do
    prompt_question_text_input "Where should the updater tarball be created?" bundle_root $HOME
    regex="^/"
    if [[ $bundle_root =~ $regex ]]; then
      is_valid_install_dir=1
    else
      is_valid_install_dir=0
      display_error "Please enter an absolute directory path."
    fi
  done

  # Assume is_valid_install_dir until find out otherwise.
  is_valid_install_dir=1

  # Assume install dir is not a file unless we find out otherwise.
  is_install_dir_a_file=0

  # If file location is a file and not a dir
  if [ -f ${bundle_root}/devportal.tgz  ]; then
    display_error "Updater tarball file exists: ${bundle_root}/devportal-update.tgz"
    prompt_question_yes_or_no "Would you like to delete this file? If you choose 'N', you will be asked to enter a different install directory." delete_install_file y
    # Delete files
    if [[ $delete_install_file == "y" ]]; then
      rm -rf ${bundle_root}/devportal-update.tgz   >> $logfile 2>&1
    else
      is_valid_install_dir=0
      is_install_dir_a_file=1
    fi
  fi

  # Create the dir if it DNE
  if [ -d $bundle_root ] ; then
    display "Drupal tarball directory already exists: ${bundle_root}"
  else
    # Only mkdir if install dir is not a file (will loop again).
    if [ ! -f $bundle_root ]; then
      mkdir --mode=755 -p $bundle_root >> $logfile 2>&1
    fi
  fi
done
display "Updater tarball will be installed in: ${bundle_root}."

tar -C $(dirname $tarball_root) -czf ${bundle_root}/devportal-update.tgz $(basename $tarball_root)
rm -rf $tarball_root

display_multiline "
--------------------------------------------------------------------------------
Drupal tarball created
--------------------------------------------------------------------------------

The Dev Portal Drupal updater tarball has been created and can be found here:
   ${bundle_root}/devportal-update.tgz

You will now need to move this tarball to the non-networked system and follow
the numbered instructions below.

Be aware of the following caveats:

 - You should take backups of both PHP code and your database before attempting
   this upgrade.
 - If you have modified any code in Drupal core or in any non-custom modules,
   your modifications are likely to be overwritten. This includes, among other
   things, any changes you may have made to .htaccess. You should assume that
   anything outside the /sites directory is owned by Drupal and may have been
   overwritten. An exception to this rule is robots.txt; if this file exists in
   the web root, it will be preserved for you.
 - If at any time you need to set filesystem permissions on Drupal files, you
   should run scripts/fix-webroot-permissions.sh from within your document root.
   The install-update.sh script will initially do this for you.

On the non-networked system, here are the steps to take:

 1. Untar the tarball and cd into the resulting directory (devportal-update).
 2. Run install-update.sh
 3. Thoroughly test the site to make sure code updates have not adversely
    affected any custom themes and/or modules you may have.

The actions of this installer are written to a log here:
   ${logfile}
If you need support during this update, please include the logfile in your
communication.

--------------------------------------------------------------------------------
"

exit 0

