#!/bin/sh
# Expected vars:
#   $logfile: the location to a file to write logs to, or /dev/null.
#   $webroot

if [[ -f /etc/redhat-release ]]; then
  devportal_group=$(grep "^Group" /etc/httpd/conf/httpd.conf | head -n 1 | cut -d " " -f2)
else
  devportal_group="www"
  if [[ -f /etc/apache2/uid.conf ]] ; then
    devportal_group=$( grep Group /etc/apache2/uid.conf | cut -d " " -f2 )
  fi
fi

prompt_question_text_input "What user should own the files under the Apache docroot?" DEVPORTAL_FILESYSTEM_OWNER root

display "Setting ownership of ${webroot} to ${DEVPORTAL_FILESYSTEM_OWNER} user and ${devportal_group} group..."
chown -R ${DEVPORTAL_FILESYSTEM_OWNER}:${devportal_group} $webroot
display_nonewline "Setting file and directory permissions of ${webroot}..."
find ${webroot} -type d -exec chmod u=rwx,g=rx,o= '{}' \; >> $logfile 2>&1
find ${webroot} -type f -exec chmod u=rw,g=r,o= '{}' \; >> $logfile 2>&1
find ${webroot}/sites -type d -name files -exec chmod ug=rwx,o= '{}' \; >> $logfile 2>&1
for x in  ${webroot}/sites/*/files; do
  find ${x} -type d -exec chmod ug=rwx,o= '{}' \; >> $logfile 2>&1
  find ${x} -type f -exec chmod ug=rw,o= '{}' \; >> $logfile 2>&1
done
find ${webroot}/sites -type d -name private -exec chmod ug=rwx,o= '{}' \; >> $logfile 2>&1
# The following directory should only exist for legacy updates, not new installs.
test -d ${webroot}/sites/default/tmp && chmod 770 ${webroot}/sites/default/tmp >> $logfile 2>&1
test -e ${webroot}/sites/default/settings.php && chmod 644 ${webroot}/sites/default/settings.php
display "done."
