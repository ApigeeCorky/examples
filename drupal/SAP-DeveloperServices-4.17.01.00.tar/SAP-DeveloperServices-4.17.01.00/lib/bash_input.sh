#!/bin/bash

###############################################################################
# Bash Input: Useful functions for interactive scripts to use, such as user
# prompting.
###############################################################################


# ------------------------------------------------------------------------------
# Prompt and get input from user for a yes or no question, defaulting to a
# default value if they just hit <Enter>.
#
# Parameters:
#   first: Question message to display to user, will be appended
#     with "[y/N]:" or "[Y/n]" as appropriate.
#   second: Variable to store the answer into. Valid
#     values are "y" or "n".
#   third: Default value, should be "y" or "n"
#
# Example:
#   prompt_question_yes_or_no "Do you like APIs?" likes_apis y
#
prompt_question_yes_or_no() {
  local question_message=$1
  local resultvar=$2
  local defaultval=$3
  local question_answered=n

  until [[ $question_answered = "y" ]]; do
    echo -n "${question_message?} "
    [[ $defaultval == 'y' ]] && echo -n "[Y/n]" || echo -n "[y/N]"
    read answer
    if [[ $answer == 'Y' ]]; then
      answer=y
    elif [[ $answer == 'N' ]]; then
    	answer=n
    fi
    if [[ -z $answer ]]; then
      question_answered=y
      answer=$defaultval
      if [[ ! -z $logfile ]]; then
        echo "${question_message}: ${answer}" >> ${logfile}
      fi
    elif [[ "y" = "$answer" || "n" = "$answer" ]]; then
      question_answered=y
      answer=$defaultval
      if [[ ! -z $logfile ]]; then
        echo "${question_message}: ${answer}" >> ${logfile}
      fi
    else
      echo "Please answer \"y\", \"n\" or <ENTER> for \"${defaultval}\""
    fi
  done
  eval $resultvar="'$answer'"
}


# ------------------------------------------------------------------------------
# Ask user a question, then capture result to a variable.
#
# Parameters:
#   first: Question message to display to user.
#   second: Variable to store the answer into
#   third: Default value for user to use if they just hit <ENTER>.
#
# Example:
#   prompt_question_text_input "What is your favorite color?" color blue
#
prompt_question_text_input() {
  local question_message=$1
  local resultvar=$2
  local default_value=$3

  if [[ ! -z $default_value ]]; then
    echo -n "${question_message?} [${default_value}]: "
  else
    echo -n "${question_message?} : "
  fi
  read answer
  if [[ -z $answer && ! -z $default_value ]]; then
    eval $resultvar="'$default_value'"
    if [[ ! -z $logfile ]]; then
      echo "${question_message}: ${default_value}" >> ${logfile}
    fi
  else
    eval $resultvar="'$answer'"
    if [[ ! -z $logfile ]]; then
      echo "${question_message}: ${answer}" >> ${logfile}
    fi
  fi
}

# ------------------------------------------------------------------------------
# Ask user a for a password without displaying on screen, then capture result
# to a variable.
#
# Parameters:
#   first: Text to prompt user with
#   second: Variable to store the answer into
#   third: (optional) default value
#
# Example:
#   prompt_question_password_input "What is your PIN number?" pin_number
#
prompt_question_password_input() {
  local question_message=$1
  local resultvar=$2

  unset bash_toolkit_answer
  while [[ -z $bash_toolkit_answer ]]; do
    echo -n "${question_message?} : "
    read -s bash_toolkit_answer
    echo ''
    if [[ ! -z $3 && -z $bash_toolkit_answer ]]; then
      bash_toolkit_answer=$3
    fi
  done
  eval $resultvar="'$bash_toolkit_answer'"
  if [[ ! -z $logfile ]]; then
    echo "${question_message}: ********" >> ${logfile}
  fi
}

