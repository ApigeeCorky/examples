#!/bin/bash

validation_url="https://www.github.com/"
timeout_seconds=10

display "Validating network is available"
# The following cURL call should generate a 301 redirect to https://github.com/.
cmd="curl --silent --location --fail --head --max-time ${timeout_seconds} ${validation_url}"
trap - ERR
curl_exit_code=$?
response_headers="$( ${cmd} )"
response_ok=$( echo "${response_headers}" | grep -c "HTTP/1.[01] 200 OK" )

# Check response of curl.
if [[ $response_ok -gt 0 ]]; then
  # Network connections success, exit out of this script.
  display "Successfully connected to ${validation_url}."
else
  # Display info on network failure.
  display_error "Cannot connect to ${validation_url}."

  # If the date of the machine is not set (or other reasons), curl will
  # fail with error code 60 (Peer certificate cannot be authenticated with
  # known CA certificates.)
  if [[ $curl_exit_code -eq 60 ]]; then
    display_error "cURL Error: Peer certificate cannot be authenticated with known CA certificates."
    display_error "cURL performs SSL certificate verification by default but has failed checking"
    display_error "${validation_url}.  Make sure your system's date is set properly."
  elif [[ $curl_exit_code -ne 0 ]]; then
    display_error "cURL encountered error number ${curl_exit_code} while attempting to connect"
    display_error "to ${validation_url}. You can look up the meaning of this number here:"
    display_error "   http://curl.haxx.se/libcurl/c/libcurl-errors.html"
  elif [[ -z $response_headers ]]; then
    display_error "The hostname could not be resolved, or the remote host timed out."
    display_error "Please make sure this computer is properly connected to the internet."
  elif [[ $( echo "$response_headers" | grep -c "HTTP:/1.[01] 301" ) -gt 0 ]]; then
    display_error "The remote host responded with a redirect header, but cURL was unable to follow"
    display_error "the redirect properly. If you are connecting through a proxy, please make sure"
    display_error "your proxy is properly configured to redirect HTTPS requests correctly."
    display_error "This problem may also occur if your network connection is under heavy load,"
    display_error "and the complete HTTP response is not received within ${timeout_seconds} seconds."
    display_error "The response headers which were received are as follows:"
    display_multiline "${response_headers}"
  else
    display_error "The remote host responded with an error condition."
    display_error "The response headers which were received are as follows:"
    display_multiline "${response_headers}"
    echo
    display_error "If you are connecting through a proxy, please make sure your proxy"
    display_error "is properly configured to redirect HTTPS requests correctly."
  fi
  echo
  display_error "The exact cURL command which was attempted is as follows:"
  display_error "   ${cmd}"

  exit 1
fi
