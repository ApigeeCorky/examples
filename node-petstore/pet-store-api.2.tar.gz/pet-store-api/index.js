'use strict';

require('./app/server');