'use strict';

const Spanner = require('@google-cloud/spanner');

// Database connection configuration properties
const projectId = 'apigee-edge-hm';
const instanceId = 'spannerconnector';

const spanner = Spanner({
    projectId: projectId
});

const instance = spanner.instance(instanceId);

module.exports = instance;