'use strict';

const DatabaseManager = require('../util/database-manager');

module.exports = {
    'createDatabase': createDatabase,
    'insert': insert,
    'update': update,
    'deleteRows': deleteRows,
    'read': read,
    'run': run
}

/**
 * Create a database.
 *
 * @param databaseId    the id of the database to create
 * @param schema        the schema used to create the database
 * @param res           the HTTP response
 */
function createDatabase(databaseId, schema, res) {
    DatabaseManager.createDatabase(databaseId, schema, res);
}

/**
 * Insert a new row into a table.
 *
 * @param databaseId    the id of the database to insert into
 * @param tableId       the id of the table to insert into
 * @param data          the row to insert
 * @param res           the HTTP response
 */
function insert(databaseId, tableId, data, res) {
    const table = getTable(databaseId, tableId);
    table.insert(data, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to insert into ' + tableId + ' ' + err.stack);
        }
        res.send(apiResponse);
    });
}

/**
 * Update a row in a table.
 *
 * @param databaseId    the id of the database to update the row in
 * @param tableId       the id of the table to update the row in
 * @param data          the updated object
 * @param res           the HTTP response
 */
function update(databaseId, tableId, data, res) {
    const table = getTable(databaseId, tableId);
    table.update(data, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to update row in table ' + tableId + ' ' + err.stack);
            return;
        }
        res.send(apiResponse);
    });
}

/**
 * Delete rows in a table.
 *
 * @param databaseId    the id of the database to delete rows from
 * @param tableId       the id of the table to delete rows from
 * @param data          the primary keys of the rows to delete
 * @param res           the HTTP response
 */
function deleteRows(databaseId, tableId, data, res) {
    const table = getTable(databaseId, tableId);
    table.deleteRows(data, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to delete rows in table ' + tableId + ' ' + err.stack);
            return;
        }
        res.send(apiResponse);
    });
}

/**
 * Read rows from a database. Limit to the first 100.
 *
 * @param databaseId    the id of the database to read from
 * @param tableId       the id of the table to read from
 * @param res           the HTTP response
 */
function read(databaseId, tableId, res) {
    const query = {
        sql: 'SELECT * FROM ' + tableId + ' LIMIT 100',
    };
    run(databaseId, query, res);
}

/**
 * Execute a query against a database.
 *
 * @param databaseId    the id of the database to execute the query against.
 * @param query         the query to execute
 * @param res           the HTTP response
 */
function run(databaseId, query, res) {
    const database = DatabaseManager.getDatabase(databaseId);
    database.run(query, function(err, rows) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to execute query against database ' + databaseId + ' ' + err.stack);
            return;
        }
        res.send(rows);
    });
}

/**
 * Get a table from a database.
 *
 * @param databaseId    the id of the database
 * @param tableId       the id of the table to get
 */
function getTable(databaseId, tableId) {
    const database = DatabaseManager.getDatabase(databaseId);
    return database.table(tableId);
}
