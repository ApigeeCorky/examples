'use strict';

const DatabaseManager = require('../util/database-manager');
const uuid = require('uuid/v4');

const database = DatabaseManager.getDatabase('challenge-db');
const petTable = database.table('Pet');
const columns = ['petStoreId', 'petId', 'displayName', 'type', 'breed', 'age'];

module.exports = {
    "getPet": getPet,
    "getAllPetsInStore": getAllPetsInStore,
    "createPet": createPet,
    "updatePet": updatePet,
    "deletePet": deletePet
}

/**
 * Get all pets in a specific store.
 *
 * @param petStoreId    the id of the pet store to get the pets from
 * @param res           the HTTP response
 */
function getAllPetsInStore(petStoreId, res) {
    const query = {
        sql: 'SELECT * FROM Pet WHERE petStoreId = @petStoreId',
        params: {
            petStoreId: petStoreId
        }
    };
    database.run(query, function(err, rows) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to get all pets in pet store' + err.stack);
            return;
        }
        res.send(rows);
    });
}

/**
 * Get a specific pet.
 *
 * @param petStoreId    the id of the pet store the pet belongs to
 * @param id            the id of the pet
 * @param res           the HTTP response
 */
function getPet(petStoreId, id, res) {
    const query = {
        'keys': [[petStoreId, id]],
        'columns': columns,
    };
    petTable.read(query, function(err, rows) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to get pet with id: ' + id + ' ' + err.stack);
            return;
        }

        const item = rows[0];
        if (item) {
            res.send(item);
        } else {
            res.sendStatus(404);
        }
    });
}

/**
 * Create new pet.
 *
 * @param petStoreId    the id of the pet store to add the pet to
 * @param pet           the pet to add
 * @param res           the HTTP response
 */
function createPet(petStoreId, pet, res) {
    pet.petStoreId = petStoreId;
    pet.petId = uuid();
    petTable.insert(pet, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to create the pet ' + err.stack);
            return;
        }

        res.send(pet);
    });
}

/**
 * Update a pet.
 *
 * @param petStoreId    the id of the pet store the pet belongs to
 * @param id            the id of the pet to update
 * @param pet           the updated pet
 * @param res           the HTTP response
 */
function updatePet(petStoreId, id, pet, res) {
    pet.petStoreId = petStoreId;
    pet.petId = id;
    petTable.update(pet, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to update the pet with id:' + id + ' ' + err.stack);
            return;
        }

        res.send(pet);
    });
}

/**
 * Delete a pet.
 *
 * @param petStoreId    the id of the pet store the pet belongs to
 * @param id            the id of the pet to delete
 * @param res           the HTTP response
 */
function deletePet(petStoreId, id, res) {
    const keys = [[petStoreId, id]];
    petTable.deleteRows(keys, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to delete the pet with id:' + id + ' ' + err.stack);
            return;
        }

        res.sendStatus(200);
    });
}
