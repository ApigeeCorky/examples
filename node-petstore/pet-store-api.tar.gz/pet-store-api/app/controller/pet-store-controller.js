'use strict';

const DatabaseManager = require('../util/database-manager');
const uuid = require('uuid/v4');

const database = DatabaseManager.getDatabase('challenge-db');
const petStoreTable = database.table('PetStore');
const columns = ['petStoreId', 'displayName', 'phoneNumber', 'address'];

module.exports = {
    'getAllPetStores': getAllPetStores,
    'getPetStore': getPetStore,
    'createPetStore': createPetStore,
    'updatePetStore': updatePetStore,
    'deletePetStore': deletePetStore
}

/**
 * Get all pet stores.
 *
 * @param res the HTTP response
 */
function getAllPetStores(res) {
    const query = {
        'columns': columns,
        'keySet': {
            'all': true
        }
    };
    petStoreTable.read(query, function(err, rows) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to get all pet stores ' + err.stack);
            return;
        }
        res.send(rows);
    });
}

/**
 * Get a pet store.
 *
 * @param id    the id of the petstore to get
 * @param res   the HTTP response
 */
function getPetStore(id, res) {
    const query = {
        'keys': [id],
        'columns': columns,
    };
    petStoreTable.read(query, function(err, rows) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to get pet store with id: ' + id + ' ' + err.stack);
            return;
        }
        const item = rows[0];
        if (item) {
           res.send(item);
        } else {
            res.sendStatus(404);
        }
    });
}

/**
 * Create a new pet store.
 *
 * @param pet   the pet store to create
 * @param res   the HTTP response
 */
function createPetStore(petStore, res) {
    petStore.petStoreId = uuid();
    petStoreTable.insert(petStore, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to create the pet store ' + err.stack);
            return;
        }

        res.send(petStore);
    });
}

/**
 * Update pet store.
 *
 * @param id        the id of the petstore to update
 * @param petStore  the updated pet store
 * @param res       the HTTP response
 */
function updatePetStore(id, petStore, res) {
    petStore.petStoreId = id;
    petStoreTable.update(petStore, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to update the pet store with id:' + id + ' ' + err.stack);
            return;
        }

        res.send(petStore);
    });
}

/**
 * Delete pet store.
 *
 * @param id    the id of the pet store to delete
 * @param res   the HTTP response
 */
function deletePetStore(id, res) {
    const keys = [id];
    petStoreTable.deleteRows(keys, function(err, apiResponse) {
        if (err) {
            console.error(err.stack);
            res.status(500).send('Failed to delete the pet store with id:' + id + ' ' + err.stack);
            return;
        }

        res.sendStatus(200);
    });
}
