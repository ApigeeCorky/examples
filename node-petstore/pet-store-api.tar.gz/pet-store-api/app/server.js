'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const PetStoreController = require('./controller/pet-store-controller');
const PetController = require('./controller/pet-controller');

// Setup express server
const port = 3000;
const server = express();
server.use(bodyParser.json());

// Get all pet stores
server.get('/petstore', function (req, res) {
    PetStoreController.getAllPetStores(res);
});

// Get a pet store
server.get('/petstore/:id', function (req, res) {
    const id = req.params.id;
    PetStoreController.getPetStore(id, res);
});

// Create new pet store
server.post('/petstore', function (req, res) {
    const body = req.body;
    PetStoreController.createPetStore(body, res);
});

// Update pet store
server.put('/petstore/:id', function (req, res) {
    const id = req.params.id;
    const body = req.body;
    PetStoreController.updatePetStore(id, body, res);
});

// Delete pet store
server.delete('/petstore/:id', function (req, res) {
    const id = req.params.id;
    PetStoreController.deletePetStore(id, res);
});

// Get all pets in a pet store
server.get('/petstore/:petStoreId/pet', function (req, res) {
    const petStoreId = req.params.petStoreId;
    PetController.getAllPetsInStore(petStoreId, res);
});

// Get a pet in a pet store
server.get('/petstore/:petStoreId/pet/:id', function (req, res) {
    const petStoreId = req.params.petStoreId;
    const id = req.params.id;
    PetController.getPet(petStoreId, id, res);
});

// Create new pet
server.post('/petstore/:petStoreId/pet', function (req, res) {
    const petStoreId = req.params.petStoreId;
    const body = req.body;
    PetController.createPet(petStoreId, body, res);
});

// Update pet
server.put('/petstore/:petStoreId/pet/:id', function (req, res) {
    const petStoreId = req.params.petStoreId;
    const id = req.params.id;
    const body = req.body;
    PetController.updatePet(petStoreId, id, body, res);
});

// Delete pet
server.delete('/petstore/:petStoreId/pet/:id', function (req, res) {
    const petStoreId = req.params.petStoreId;
    const id = req.params.id;
    PetController.deletePet(petStoreId, id, res);
});

// Listen for incoming requests
server.listen(port, function () {
    console.log('Server listening on port %s', port);
})
