'use strict';

const instance = require('./spanner-provider');

// // Database initialization request
// const initRequest = {
//     schema: [
//         `CREATE TABLE PetStore (
//           petStoreId    STRING(1024) NOT NULL,
//           displayName   STRING(1024),
//           phoneNumber   STRING(1024),
//           address       STRING(1024)
//         ) PRIMARY KEY (petStoreId)`,
//         `CREATE TABLE Pet (
//           petStoreId    STRING(1024) NOT NULL,
//           petId         STRING(1024) NOT NULL,
//           displayName   STRING(1024),
//           type          STRING(1024),
//           breed         STRING(1024),
//           age           INT64
//         ) PRIMARY KEY (petStoreId, petId),
//         INTERLEAVE IN PARENT PetStore ON DELETE CASCADE`
//     ]
// };

module.exports = {
    'getDatabase': getDatabase,
    'createDatabase': createDatabase,
    'createTable': createTable,
    'executeQuery': executeQuery
}

/**
 * Get an instance of a database.
 *
 * NOTE: the database may not yet exist. You can call getDatabase().exists() to verify.
 *
 * @param databaseId    the id of the database to get
 * @returns             the database
 */
function getDatabase(databaseId) {
    return instance.database(databaseId);
}

/**
 * Create a new database.
 *
 * Responds with 409, if a database with the given id already exists.
 *
 * @param databaseId    the id of the database to create
 * @param schema        the schema for the database
 * @param res           the HTTP response
 */
function createDatabase(databaseId, schema, res) {
    const database = instance.database(databaseId);
    database.exists(function(err, exists) {

        // Check if database already exists
        if (exists) {
            res.status(409).send('Database with given id already exists: ' + databaseId);
            return;
        }

        // Create database if it does not already exist
        instance.createDatabase(databaseId, schema, function callback(err, database, operation, apiResponse) {
            if (err) {
                console.error(err.stack);
                res.status(500).send('Failed to create database: ' + databaseId + ' ' + err.stack);
                return;
            }

            operation
                .on('error', function (err) {
                    console.error(err.stack);
                    res.status(500).send('Failed to create database: ' + databaseId + ' ' + err.stack);
                })
                .on('complete', function () {
                    res.send(databaseId);
                });
        });
    });
}

/**
 * Create a new table.
 *
 * @param databaseId    the id of the database to create the table in
 * @param schema        the schema of the table
 * @param res           the HTTP response
 */
function createTable(databaseId, schema, res) {
    const database = getDatabase(databaseId);

    database.exists(function(err, exists) {

        // Check if database exists
        if (!exists) {
            res.status(404).send('Database does not exist: ' + databaseId);
            return;
        }

        // Create table
        database.createTable(schema, function(err, table, operation, apiResponse) {
            if (err) {
                console.error(err.stack);
                res.status(500).send('Failed to create table in database: ' + databaseId + ' ' + err.stack);
            }

            operation
                .on('error', function(err) {
                    console.error(err.stack);
                    res.status(500).send('Failed to create table in database: ' + databaseId + ' ' + err.stack);
                })
                .on('complete', function() {
                    res.send("Table created successfully")
                });
        });
    });
}

/**
 * Execute a query against a database.
 *
 * @param databaseId    the id of the database to execute the database against
 * @param query         the query to execute
 * @param res           the HTTP response
 */
function executeQuery(databaseId, query, res) {
    const database = getDatabase(databaseId);

    database.exists(function(err, exists) {

        // Check if database exists
        if (!exists) {
            res.status(404).send('Database does not exist: ' + databaseId);
            return;
        }

        // Execute the query
        database.run(query, function(err, rows) {
            if (err) {
                console.error(err.stack);
                res.status(500).send('Failed to execute query:\n' + query + '\n' + err.stack);
                return;
            }
            res.send(rows);
        });
    });
}
